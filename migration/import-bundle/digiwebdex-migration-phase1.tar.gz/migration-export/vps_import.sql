-- ============================================================
-- DigiWebDex VPS Data Import
-- Run from /var/www/digiwebdex/migration/import/ on the VPS:
--   docker cp . digiwebdex-postgres:/import/
--   docker exec -i digiwebdex-postgres psql -U digiwebdex -d digiwebdex -f /import/vps_import.sql
-- ============================================================

BEGIN;

-- Disable triggers and FK checks for bulk load
SET session_replication_role = replica;

-- Wipe existing (empty) data so re-runs are safe
TRUNCATE TABLE
  affiliate_clicks, affiliate_commissions, affiliate_withdrawals, affiliates,
  audit_logs, automation_logs,
  blog_categories, blog_post_tags, blog_posts, blog_related_posts, blog_tags,
  bundle_discounts, cart_items, case_studies, chatbot_conversations,
  consultation_bookings, contact_messages, coupons,
  custom_field_values, custom_fields,
  domain_logs, domain_pricing, domain_search_logs, domains,
  homepage_sections, hosting_accounts,
  invoice_items, invoices,
  landing_pages, lead_logs, leads, location_pages,
  manual_payments, milestones,
  notification_templates, notifications,
  order_items, order_meta, orders,
  payments, phone_otps, profiles,
  project_files, projects,
  proposal_logs, proposal_templates, proposals,
  renewal_logs,
  reseller_clients, reseller_earnings, reseller_logs, reseller_withdrawals, resellers,
  role_permissions,
  seo_settings, servers,
  service_categories, service_packages, services,
  sitemap_entries,
  subscription_billing_history, subscription_logs, subscriptions,
  support_tickets, system_settings,
  ticket_logs, ticket_messages,
  tracking_event_logs, user_roles, users
RESTART IDENTITY CASCADE;

-- ============================================================
-- USERS: import from Lovable Cloud auth.users
-- password_hash set to sentinel 'NEEDS_RESET' (login route detects this
-- and forces the password-reset email flow on first login attempt)
-- ============================================================
CREATE TEMP TABLE _au (id uuid, email text, full_name text, phone text,
                       created_at timestamptz, email_confirmed_at timestamptz,
                       last_sign_in_at timestamptz);
\COPY _au FROM '/import/_auth_users.csv' WITH (FORMAT csv, HEADER true);

INSERT INTO users (id, email, password_hash, email_verified, email_verified_at,
                   raw_user_meta_data, created_at, last_sign_in_at, is_active)
SELECT id, email, 'NEEDS_RESET',
       email_confirmed_at IS NOT NULL,
       email_confirmed_at,
       jsonb_build_object('full_name', full_name, 'phone', phone),
       created_at, last_sign_in_at, true
FROM _au;

-- ============================================================
-- All other public tables: COPY from CSV in any order (FK disabled)
-- ============================================================
\COPY profiles                     FROM '/import/profiles.csv'                     WITH (FORMAT csv, HEADER true);
\COPY user_roles                   FROM '/import/user_roles.csv'                   WITH (FORMAT csv, HEADER true);
\COPY role_permissions             FROM '/import/role_permissions.csv'             WITH (FORMAT csv, HEADER true);
\COPY service_categories           FROM '/import/service_categories.csv'           WITH (FORMAT csv, HEADER true);
\COPY services                     FROM '/import/services.csv'                     WITH (FORMAT csv, HEADER true);
\COPY service_packages             FROM '/import/service_packages.csv'             WITH (FORMAT csv, HEADER true);
\COPY domain_pricing               FROM '/import/domain_pricing.csv'               WITH (FORMAT csv, HEADER true);
\COPY servers                      FROM '/import/servers.csv'                      WITH (FORMAT csv, HEADER true);
\COPY bundle_discounts             FROM '/import/bundle_discounts.csv'             WITH (FORMAT csv, HEADER true);
\COPY coupons                      FROM '/import/coupons.csv'                      WITH (FORMAT csv, HEADER true);
\COPY affiliates                   FROM '/import/affiliates.csv'                   WITH (FORMAT csv, HEADER true);
\COPY affiliate_clicks             FROM '/import/affiliate_clicks.csv'             WITH (FORMAT csv, HEADER true);
\COPY affiliate_commissions        FROM '/import/affiliate_commissions.csv'        WITH (FORMAT csv, HEADER true);
\COPY affiliate_withdrawals        FROM '/import/affiliate_withdrawals.csv'        WITH (FORMAT csv, HEADER true);
\COPY resellers                    FROM '/import/resellers.csv'                    WITH (FORMAT csv, HEADER true);
\COPY reseller_clients             FROM '/import/reseller_clients.csv'             WITH (FORMAT csv, HEADER true);
\COPY reseller_earnings            FROM '/import/reseller_earnings.csv'            WITH (FORMAT csv, HEADER true);
\COPY reseller_logs                FROM '/import/reseller_logs.csv'                WITH (FORMAT csv, HEADER true);
\COPY reseller_withdrawals         FROM '/import/reseller_withdrawals.csv'         WITH (FORMAT csv, HEADER true);
\COPY orders                       FROM '/import/orders.csv'                       WITH (FORMAT csv, HEADER true);
\COPY order_items                  FROM '/import/order_items.csv'                  WITH (FORMAT csv, HEADER true);
\COPY order_meta                   FROM '/import/order_meta.csv'                   WITH (FORMAT csv, HEADER true);
\COPY invoices                     FROM '/import/invoices.csv'                     WITH (FORMAT csv, HEADER true);
\COPY invoice_items                FROM '/import/invoice_items.csv'                WITH (FORMAT csv, HEADER true);
\COPY payments                     FROM '/import/payments.csv'                     WITH (FORMAT csv, HEADER true);
\COPY manual_payments              FROM '/import/manual_payments.csv'              WITH (FORMAT csv, HEADER true);
\COPY domains                      FROM '/import/domains.csv'                      WITH (FORMAT csv, HEADER true);
\COPY hosting_accounts             FROM '/import/hosting_accounts.csv'             WITH (FORMAT csv, HEADER true);
\COPY subscriptions                FROM '/import/subscriptions.csv'                WITH (FORMAT csv, HEADER true);
\COPY subscription_billing_history FROM '/import/subscription_billing_history.csv' WITH (FORMAT csv, HEADER true);
\COPY subscription_logs            FROM '/import/subscription_logs.csv'            WITH (FORMAT csv, HEADER true);
\COPY projects                     FROM '/import/projects.csv'                     WITH (FORMAT csv, HEADER true);
\COPY project_files                FROM '/import/project_files.csv'                WITH (FORMAT csv, HEADER true);
\COPY milestones                   FROM '/import/milestones.csv'                   WITH (FORMAT csv, HEADER true);
\COPY proposal_templates           FROM '/import/proposal_templates.csv'           WITH (FORMAT csv, HEADER true);
\COPY proposals                    FROM '/import/proposals.csv'                    WITH (FORMAT csv, HEADER true);
\COPY proposal_logs                FROM '/import/proposal_logs.csv'                WITH (FORMAT csv, HEADER true);
\COPY support_tickets              FROM '/import/support_tickets.csv'              WITH (FORMAT csv, HEADER true);
\COPY ticket_messages              FROM '/import/ticket_messages.csv'              WITH (FORMAT csv, HEADER true);
\COPY ticket_logs                  FROM '/import/ticket_logs.csv'                  WITH (FORMAT csv, HEADER true);
\COPY leads                        FROM '/import/leads.csv'                        WITH (FORMAT csv, HEADER true);
\COPY lead_logs                    FROM '/import/lead_logs.csv'                    WITH (FORMAT csv, HEADER true);
\COPY contact_messages             FROM '/import/contact_messages.csv'             WITH (FORMAT csv, HEADER true);
\COPY consultation_bookings        FROM '/import/consultation_bookings.csv'        WITH (FORMAT csv, HEADER true);
\COPY blog_categories              FROM '/import/blog_categories.csv'              WITH (FORMAT csv, HEADER true);
\COPY blog_tags                    FROM '/import/blog_tags.csv'                    WITH (FORMAT csv, HEADER true);
\COPY blog_posts                   FROM '/import/blog_posts.csv'                   WITH (FORMAT csv, HEADER true);
\COPY blog_post_tags               FROM '/import/blog_post_tags.csv'               WITH (FORMAT csv, HEADER true);
\COPY blog_related_posts           FROM '/import/blog_related_posts.csv'           WITH (FORMAT csv, HEADER true);
\COPY case_studies                 FROM '/import/case_studies.csv'                 WITH (FORMAT csv, HEADER true);
\COPY landing_pages                FROM '/import/landing_pages.csv'                WITH (FORMAT csv, HEADER true);
\COPY location_pages               FROM '/import/location_pages.csv'               WITH (FORMAT csv, HEADER true);
\COPY homepage_sections            FROM '/import/homepage_sections.csv'            WITH (FORMAT csv, HEADER true);
\COPY system_settings              FROM '/import/system_settings.csv'              WITH (FORMAT csv, HEADER true);
\COPY seo_settings                 FROM '/import/seo_settings.csv'                 WITH (FORMAT csv, HEADER true);
\COPY sitemap_entries              FROM '/import/sitemap_entries.csv'              WITH (FORMAT csv, HEADER true);
\COPY notification_templates       FROM '/import/notification_templates.csv'       WITH (FORMAT csv, HEADER true);
\COPY notifications                FROM '/import/notifications.csv'                WITH (FORMAT csv, HEADER true);
\COPY audit_logs                   FROM '/import/audit_logs.csv'                   WITH (FORMAT csv, HEADER true);
\COPY automation_logs              FROM '/import/automation_logs.csv'              WITH (FORMAT csv, HEADER true);
\COPY renewal_logs                 FROM '/import/renewal_logs.csv'                 WITH (FORMAT csv, HEADER true);
\COPY domain_logs                  FROM '/import/domain_logs.csv'                  WITH (FORMAT csv, HEADER true);
\COPY domain_search_logs           FROM '/import/domain_search_logs.csv'           WITH (FORMAT csv, HEADER true);
\COPY tracking_event_logs          FROM '/import/tracking_event_logs.csv'          WITH (FORMAT csv, HEADER true);
\COPY chatbot_conversations        FROM '/import/chatbot_conversations.csv'        WITH (FORMAT csv, HEADER true);
\COPY phone_otps                   FROM '/import/phone_otps.csv'                   WITH (FORMAT csv, HEADER true);
\COPY cart_items                   FROM '/import/cart_items.csv'                   WITH (FORMAT csv, HEADER true);
\COPY custom_fields                FROM '/import/custom_fields.csv'                WITH (FORMAT csv, HEADER true);
\COPY custom_field_values          FROM '/import/custom_field_values.csv'          WITH (FORMAT csv, HEADER true);

-- Re-enable triggers
SET session_replication_role = DEFAULT;

COMMIT;

-- Verification
SELECT 'users' AS t, COUNT(*) FROM users
UNION ALL SELECT 'profiles', COUNT(*) FROM profiles
UNION ALL SELECT 'user_roles', COUNT(*) FROM user_roles
UNION ALL SELECT 'orders', COUNT(*) FROM orders
UNION ALL SELECT 'invoices', COUNT(*) FROM invoices
UNION ALL SELECT 'invoice_items', COUNT(*) FROM invoice_items
UNION ALL SELECT 'services', COUNT(*) FROM services
UNION ALL SELECT 'blog_posts', COUNT(*) FROM blog_posts
ORDER BY t;
