#!/bin/bash
# ============================================================
# DigiWebDex VPS Migration — Phase 1 (data import)
# Upload this folder to the VPS at /root/digiwebdex-migration/
# then run:  bash /root/digiwebdex-migration/RUN_ON_VPS.sh
# ============================================================
set -e

MIG_DIR="$(cd "$(dirname "$0")" && pwd)"
CONTAINER="digiwebdex-postgres"
UPLOAD_DIR="/var/www/digiwebdex/migration/backend/uploads/invoices"

echo "=== Step 1/4: copying CSVs into postgres container ==="
docker exec "$CONTAINER" rm -rf /import
docker exec "$CONTAINER" mkdir -p /import
docker cp "$MIG_DIR/." "$CONTAINER":/import/
echo "  copied $(ls "$MIG_DIR"/*.csv | wc -l) CSV files"

echo ""
echo "=== Step 2/4: running vps_import.sql (this truncates current data) ==="
docker exec -i "$CONTAINER" psql -U digiwebdex -d digiwebdex -v ON_ERROR_STOP=1 -f /import/vps_import.sql

echo ""
echo "=== Step 3/4: copying invoice PDFs to nginx-served uploads ==="
mkdir -p "$UPLOAD_DIR"
cp -v "$MIG_DIR"/storage/invoices/*.pdf "$UPLOAD_DIR/" 2>/dev/null || echo "  no PDFs found"
chown -R www-data:www-data "$UPLOAD_DIR" 2>/dev/null || true
echo "  $(ls "$UPLOAD_DIR" | wc -l) files in $UPLOAD_DIR"

echo ""
echo "=== Step 4/4: cleanup ==="
docker exec "$CONTAINER" rm -rf /import
echo ""
echo "✅ DONE. Verify counts above match: users=29, invoices=28, orders=38, profiles=29"
echo ""
echo "Next: rebuild backend & frontend (Phase 2/3 deploy will be a separate bundle)"
