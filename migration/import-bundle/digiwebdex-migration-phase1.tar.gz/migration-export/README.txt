DigiWebDex VPS Migration — Phase 1 Data Bundle
===============================================

Contents:
  *.csv                  → 69 public tables exported from Lovable Cloud
  _auth_users.csv        → 29 registered users (passwords NOT included;
                            all will be force-reset on first login)
  storage/invoices/*.pdf → 19 generated invoice PDFs (146 MB)
  vps_import.sql         → SQL script run inside the postgres container
  RUN_ON_VPS.sh          → Bash wrapper — execute this

How to run on the VPS:
  1. From your local PC (PowerShell):
       scp -r digiwebdex-migration root@srv1468666:/root/

  2. SSH into the VPS:
       ssh root@srv1468666

  3. Execute:
       bash /root/digiwebdex-migration/RUN_ON_VPS.sh

  4. Verify the printed row counts:
       users=29  profiles=29  orders=38  invoices=28  invoice_items=66

IMPORTANT: All users will see "password reset required" on first login.
Phase 4 of the migration plan adds the email-based reset flow.
